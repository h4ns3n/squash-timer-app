<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function erd_render_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Relay Doubles Timer Settings', 'erdct-textdomain'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('erd_settings_group');
            $settings = get_option('erd_settings', array());
            ?>

            <h2><?php esc_html_e('Schedule Settings', 'erdct-textdomain'); ?></h2>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Number of Schedules', 'erdct-textdomain'); ?></th>
                    <td>
                        <select name="erd_settings[number_of_schedules]">
                            <option value="1" <?php selected($settings['number_of_schedules'] ?? 1, 1); ?>>1</option>
                            <option value="2" <?php selected($settings['number_of_schedules'] ?? 1, 2); ?>>2</option>
                        </select>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e('Timer Display Settings', 'erdct-textdomain'); ?></h2>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Timer Font Size (pt)', 'erdct-textdomain'); ?></th>
                    <td>
                        <input type="number" name="erd_settings[timer_font_size]" value="<?php echo esc_attr($settings['timer_font_size'] ?? 20); ?>" min="10" max="100" />
                    </td>
                </tr>
            </table>

            <?php for ($schedule = 1; $schedule <= 2; $schedule++): ?>
                <div class="schedule-section" style="<?php echo ($settings['number_of_schedules'] ?? 1) < $schedule ? 'display:none;' : ''; ?>">
                    <h3><?php echo sprintf(esc_html__('Schedule %d', 'erdct-textdomain'), $schedule); ?></h3>
                    <table class="form-table">
                        <tr valign="top">
                            <th scope="row"><?php esc_html_e('Date', 'erdct-textdomain'); ?></th>
                            <td>
                                <input type="date" name="erd_settings[schedule_<?php echo $schedule; ?>_date]" value="<?php echo esc_attr($settings["schedule_{$schedule}_date"] ?? ''); ?>" />
                            </td>
                        </tr>
                        <?php for ($court = 1; $court <= 4; $court++): ?>
                            <tr valign="top">
                                <th scope="row"><?php echo sprintf(esc_html__('Court %d Team 1', 'erdct-textdomain'), $court); ?></th>
                                <td>
                                    <input type="text" name="erd_settings[schedule_<?php echo $schedule; ?>_court_<?php echo $court; ?>_team_1]" value="<?php echo esc_attr($settings["schedule_{$schedule}_court_{$court}_team_1"] ?? ''); ?>" />
                                </td>
                            </tr>
                            <tr valign="top">
                                <th scope="row"><?php echo sprintf(esc_html__('Court %d Team 2', 'erdct-textdomain'), $court); ?></th>
                                <td>
                                    <input type="text" name="erd_settings[schedule_<?php echo $schedule; ?>_court_<?php echo $court; ?>_team_2]" value="<?php echo esc_attr($settings["schedule_{$schedule}_court_{$court}_team_2"] ?? ''); ?>" />
                                </td>
                            </tr>
                        <?php endfor; ?>
                    </table>
                </div>
            <?php endfor; ?>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function erd_register_settings() {
    register_setting('erd_settings_group', 'erd_settings');
}

add_action('admin_init', 'erd_register_settings');

function erd_add_settings_page() {
    add_options_page(
        __('Relay Doubles Timer Settings', 'erdct-textdomain'), // Page title
        __('Relay Doubles Timer', 'erdct-textdomain'),           // Menu title
        'manage_options',                                        // Capability
        'erd-settings',                                          // Menu slug
        'erd_render_settings_page'                               // Callback function
    );
}

add_action('admin_menu', 'erd_add_settings_page');
?>