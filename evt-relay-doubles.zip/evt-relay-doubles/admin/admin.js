// admin/admin.js
jQuery(document).ready(function($){
    // Additional admin-side JavaScript can go here if needed.
});