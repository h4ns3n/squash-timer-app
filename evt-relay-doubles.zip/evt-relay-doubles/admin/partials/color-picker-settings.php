<script>
    jQuery(document).ready(function($) {
        $('.erd-color-picker').wpColorPicker();
    });
</script>